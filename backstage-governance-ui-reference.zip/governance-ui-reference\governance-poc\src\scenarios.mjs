import { stringify } from 'yaml';

export function api(name, operationId = 'listAdvances') {
  return {
    openapi: '3.1.0',
    info: { title: name, version: '1.0.0', description: 'Synthetic member advance interface.' },
    paths: {
      '/advances': {
        get: {
          ...(operationId ? { operationId } : {}),
          summary: 'List member advances',
          responses: {
            200: { description: 'Advance list', content: { 'application/json': { schema: { $ref: '../schemas/advance.yaml' } } } },
          },
        },
      },
    },
  };
}

export function catalog(name, type = 'openapi', owner = 'group:default/advances-team') {
  return {
    apiVersion: 'backstage.io/v1alpha1', kind: 'API',
    metadata: { name, description: 'Synthetic demonstration entity.' },
    spec: {
      type, lifecycle: 'experimental', ...(owner ? { owner } : {}),
      system: 'system:default/advance-processing', definition: { $text: `../${type}/${name}.yaml` },
    },
  };
}

export function event() {
  return {
    asyncapi: '3.0.0',
    info: { title: 'Advance Events', version: '1.0.0', description: 'Synthetic advance verification events.' },
    channels: {
      advanceVerified: {
        address: 'demo.advances.verified.v1',
        messages: {
          advanceVerified: {
            name: 'AdvanceVerified', title: 'Advance verified',
            payload: { type: 'object', properties: { advanceId: { type: 'string' } }, required: ['advanceId'] },
          },
        },
      },
    },
    operations: {
      publishAdvanceVerified: {
        action: 'send', summary: 'Publish an advance verification',
        channel: { $ref: '#/channels/advanceVerified' },
        messages: [{ $ref: '#/channels/advanceVerified/messages/advanceVerified' }],
      },
    },
  };
}

export function baseSnapshot() {
  const snapshot = new Map();
  snapshot.set('schemas/advance.yaml', stringify({ type: 'object', properties: { advanceId: { type: 'string' } } }));
  for (let index = 1; index <= 10; index += 1) {
    const name = `legacy-api-${String(index).padStart(2, '0')}`;
    snapshot.set(`openapi/${name}.yaml`, stringify(api(`Legacy API ${index}`, null)));
    snapshot.set(`catalog/${name}.yaml`, stringify(catalog(name)));
  }
  return snapshot;
}

function addApi(snapshot) {
  snapshot.set('openapi/member-api.yaml', stringify(api('New Member API', 'listMemberAdvances')));
  snapshot.set('catalog/member-api.yaml', stringify(catalog('member-api')));
}

function addEvent(snapshot) {
  snapshot.set('asyncapi/advance-events.yaml', stringify(event()));
  snapshot.set('catalog/advance-events.yaml', stringify(catalog('advance-events', 'asyncapi')));
}

export const scenarios = [
  { id: 'compliant-api', title: 'Compliant new API', expected: 'PASS', summary: 'A new API passes beside ten legacy violations.', mutate: addApi },
  { id: 'missing-owner', title: 'Missing owner', expected: 'FAIL', summary: 'The new catalog entity has no accountable owner.', mutate(snapshot) {
    addApi(snapshot);
    snapshot.set('catalog/member-api.yaml', stringify(catalog('member-api', 'openapi', null)));
  } },
  { id: 'compliant-event', title: 'Compliant new event', expected: 'PASS', summary: 'An AsyncAPI 3.0 document and its catalog entity pass.', mutate: addEvent },
  { id: 'invalid-event', title: 'Invalid event structure', expected: 'FAIL', summary: 'An invalid operation action fails AsyncAPI validation.', mutate(snapshot) {
    addEvent(snapshot);
    const document = event();
    document.operations.publishAdvanceVerified.action = 'publish';
    snapshot.set('asyncapi/advance-events.yaml', stringify(document));
  } },
  { id: 'new-legacy-violation', title: 'New debt in a legacy API', expected: 'FAIL', summary: 'A new operation lacks an identifier; old debt stays separate.', mutate(snapshot) {
    const document = api('Legacy API 1', null);
    document.paths['/members'] = { get: { responses: { 200: { description: 'Member list' } } } };
    snapshot.set('openapi/legacy-api-01.yaml', stringify(document));
  } },
  { id: 'legacy-fixed', title: 'Legacy issue resolved', expected: 'PASS', summary: 'Fixing one legacy operation reduces known debt from ten to nine.', mutate(snapshot) {
    snapshot.set('openapi/legacy-api-01.yaml', stringify(api('Legacy API 1', 'listLegacyAdvances')));
  } },
  { id: 'shared-schema-broken', title: 'Shared schema regression', expected: 'FAIL', summary: 'Only a schema changes; dependent API documents are revalidated.', mutate(snapshot) {
    snapshot.set('schemas/advance.yaml', stringify({ type: 42 }));
  } },
  { id: 'malformed-yaml', title: 'Unreadable specification', expected: 'FAIL', summary: 'Malformed YAML fails before linting.', mutate(snapshot) {
    snapshot.set('openapi/member-api.yaml', 'openapi: 3.1.0\ninfo: [unfinished\n');
  } },
  { id: 'unsupported-version', title: 'Unsupported version', expected: 'FAIL', summary: 'An unsupported AsyncAPI version cannot silently pass.', mutate(snapshot) {
    const document = event();
    document.asyncapi = '2.6.0';
    snapshot.set('asyncapi/advance-events.yaml', stringify(document));
  } },
  { id: 'documentation-warning', title: 'Documentation warning', expected: 'PASS', summary: 'A missing business description is visible without blocking.', mutate(snapshot) {
    addApi(snapshot);
    const document = api('New Member API', 'listMemberAdvances');
    delete document.info.description;
    snapshot.set('openapi/member-api.yaml', stringify(document));
  } },
];

export function scenarioSnapshot(id) {
  const scenario = scenarios.find(item => item.id === id);
  if (!scenario) throw new Error(`Unknown scenario: ${id}. Choose: ${scenarios.map(item => item.id).join(', ')}`);
  const snapshot = baseSnapshot();
  scenario.mutate(snapshot);
  return snapshot;
}