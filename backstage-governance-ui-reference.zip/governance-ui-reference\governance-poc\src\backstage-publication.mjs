import path from 'node:path';
import { parse, stringify } from 'yaml';
import { bundle, compareSnapshots } from './engine.mjs';

const entity = (kind, name, spec, description) => ({
  apiVersion: 'backstage.io/v1alpha1', kind,
  metadata: { name, description, tags: ['synthetic', 'local-demo'] },
  spec,
});

export async function buildBackstagePublication(base, head) {
  const result = await compareSnapshots(base, head);
  if (result.exitCode !== 0) throw new Error(`Publication blocked: ${result.status}, ${result.counts.blocking} blocking findings.`);
  const entities = [
    entity('Group', 'advances-team', { type: 'team', profile: { displayName: 'Advances Team' }, children: [], members: ['demo-user'] }, 'Synthetic interface-owning team.'),
    entity('User', 'demo-user', { profile: { displayName: 'Demo Developer' }, memberOf: ['advances-team'] }, 'Synthetic demo identity.'),
    entity('Domain', 'member-services', { owner: 'group:default/advances-team' }, 'Synthetic member services domain.'),
    entity('System', 'advance-processing', { owner: 'group:default/advances-team', domain: 'member-services' }, 'Synthetic advance processing system.'),
  ];
  const apiNames = [];
  for (const [file, text] of head) {
    if (!file.startsWith('catalog/')) continue;
    const apiEntity = parse(text);
    const definitionFile = path.posix.normalize(path.posix.join(path.posix.dirname(file), apiEntity.spec.definition.$text));
    const definition = await bundle(head, definitionFile, parse(head.get(definitionFile)));
    const legacy = result.findings.filter(item => item.file === definitionFile && item.state === 'existing').length;
    apiEntity.metadata.tags = ['synthetic', apiEntity.spec.type, ...(legacy ? ['legacy-debt'] : ['compliant'])];
    apiEntity.metadata.annotations = {
      'governance.local/legacy-findings': String(legacy),
      'governance.local/ruleset': result.rulesetVersion,
      'backstage.io/spectral-ruleset-url': `http://localhost:3001/spectral-rules/${result.rulesetVersion}/${apiEntity.spec.type}.json`,
    };
    apiEntity.metadata.links = [{ url: `http://localhost:3001/governance-report/index.html#${legacy ? 'new-legacy-violation' : apiEntity.spec.type === 'asyncapi' ? 'compliant-event' : 'compliant-api'}`, title: 'Governance scenarios', icon: 'dashboard' }];
    apiEntity.spec.definition = stringify(definition);
    entities.push(apiEntity);
    apiNames.push(apiEntity.metadata.name);
  }
  entities.push(
    entity('Component', 'advance-service', { type: 'service', lifecycle: 'experimental', owner: 'advances-team', system: 'advance-processing', providesApis: apiNames }, 'Synthetic producer of the sample APIs and events.'),
    entity('Component', 'member-portal', { type: 'website', lifecycle: 'experimental', owner: 'advances-team', system: 'advance-processing', consumesApis: apiNames.filter(name => !name.startsWith('legacy-')) }, 'Synthetic consumer of the new API and event interface.'),
  );
  return { entities, result };
}