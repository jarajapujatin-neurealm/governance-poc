import {
  createFrontendPlugin,
  createRouteRef,
  PageBlueprint,
} from '@backstage/frontend-plugin-api';
import VerifiedUserIcon from '@material-ui/icons/VerifiedUser';

const governanceRouteRef = createRouteRef();

export const governancePlugin = createFrontendPlugin({
  pluginId: 'local-governance',
  extensions: [
    PageBlueprint.make({
      params: {
        path: '/governance',
        title: 'Governance',
        icon: <VerifiedUserIcon />,
        routeRef: governanceRouteRef,
        noHeader: true,
        loader: async () => (
          <iframe
            title="Local interface governance results"
            src="/governance-report/index.html"
            style={{ width: '100%', height: '100vh', border: 0, display: 'block' }}
          />
        ),
      },
    }),
  ],
});