import assert from 'node:assert/strict';
import { test } from 'node:test';
import { lintDocument } from '../src/rules.mjs';

test('real Spectral flags a missing operationId but accepts a named operation', async () => {
  const specification = {
    openapi: '3.0.3',
    info: { title: 'Demo API', version: '1.0.0', description: 'Synthetic interface.' },
    paths: { '/advances': { get: { responses: { 200: { description: 'Success' } } } } },
  };
  const findings = await lintDocument(specification, 'openapi');
  assert.equal(findings.length, 1);
  assert.equal(findings[0].code, 'api-operation-id');
  assert.equal(findings[0].severity, 0);
  specification.paths['/advances'].get.operationId = 'listAdvances';
  assert.deepEqual(await lintDocument(specification, 'openapi'), []);
});