export function mountReport(payload, icons, rules) {
  const escape = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  const element = id => document.getElementById(id);
  const hash = location.hash.slice(1);
  let selected = payload.results.find(result => result.id === hash) ?? payload.results[0];
  let tab = 'findings';
  let filter = 'new';
  let query = '';
  const statusClass = status => status === 'PASS' ? 'pass' : status === 'FAIL' ? 'fail' : 'incomplete';
  const matches = value => JSON.stringify(value).toLowerCase().includes(query);

  function renderContent() {
    document.querySelectorAll('[data-tab]').forEach(button => {
      button.setAttribute('aria-selected', String(button.dataset.tab === tab));
      button.tabIndex = button.dataset.tab === tab ? 0 : -1;
    });
    element('filters').hidden = tab !== 'findings';
    element('filters').innerHTML = ['new', 'existing', 'resolved', 'all'].map(state => {
      const count = selected.findings.filter(item => state === 'all' || item.state === state).length;
      return `<button type="button" data-filter="${state}" aria-pressed="${state === filter}">${state[0].toUpperCase() + state.slice(1)} <span>${count}</span></button>`;
    }).join('');
    if (selected.error || selected.baselineInvalid) {
      element('content').innerHTML = `<div class="empty-state incomplete">${icons['circle-alert']}<h3>Validation incomplete</h3><p>${escape(selected.error ?? 'Target snapshot is structurally invalid. A trustworthy baseline is unavailable.')}</p></div>`;
      return;
    }
    if (tab === 'findings') {
      const items = selected.findings.filter(item => (filter === 'all' || item.state === filter) && matches(item));
      element('content').innerHTML = items.length ? `<div class="table-scroll"><table><thead><tr><th>Finding</th><th>File &amp; location</th><th>State</th></tr></thead><tbody>${items.map(item => `<tr><td><span class="severity ${item.severity}">${item.severity === 'error' ? icons['circle-alert'] : icons['file-code']} ${escape(item.code)}</span><details class="finding-detail"><summary>${escape(item.message.split('\n')[0])}</summary><pre>${escape(item.message)}</pre></details></td><td><span class="file-name">${escape(item.file)}</span><code class="location">${escape(item.location)}</code></td><td><span class="finding-state ${item.state}">${escape(item.state)}</span></td></tr>`).join('')}</tbody></table></div>` : `<div class="empty-state">${icons[selected.status === 'PASS' ? 'shield-check' : 'search']}<h3>${query ? 'No matching findings' : `No ${escape(filter === 'all' ? '' : filter + ' ')}findings`}</h3><p>${selected.counts.blocking} blocking / ${selected.counts.existing} existing / ${selected.counts.resolved} resolved</p></div>`;
    } else if (tab === 'changes') {
      const items = Object.entries(selected.sources).filter(([file, source]) => matches({ file, ...source }));
      element('content').innerHTML = items.length ? items.map(([file, source]) => `<details class="source-file" open><summary>${icons['file-code']} ${escape(file)} <span>${source.before ? source.after ? 'MODIFIED' : 'DELETED' : 'ADDED'}</span></summary><div class="source-grid"><div><h3>Target branch</h3><pre>${escape(source.before || '(not present)')}</pre></div><div><h3>Proposed change</h3><pre>${escape(source.after || '(deleted)')}</pre></div></div></details>`).join('') : '<div class="empty-state"><h3>No matching changes</h3></div>';
    } else if (tab === 'catalog') {
      const items = selected.inventory.filter(matches);
      element('content').innerHTML = `<div class="inventory-heading">${icons.network}<span>API entities <strong>${items.length}</strong></span><span class="muted">Local metadata / Not a Backstage instance</span></div><div class="table-scroll"><table><thead><tr><th>Entity</th><th>Owner / System</th><th>Type / Lifecycle</th></tr></thead><tbody>${items.map(item => `<tr><td><strong>${escape(item.name)}</strong><span class="location">${escape(item.definition)}</span></td><td>${escape(item.owner ?? 'UNASSIGNED')}<span class="location">${escape(item.system)}</span></td><td>${escape(item.type)}<span class="location">${escape(item.lifecycle)}</span></td></tr>`).join('')}</tbody></table></div>`;
    } else {
      const checks = [
        { code: 'syntax / supported-version', kind: 'all specifications', severity: 'error', description: 'Readable YAML/JSON and declared supported versions. Never baselined.' },
        { code: 'spec-reference / spec-structure', kind: 'OpenAPI / AsyncAPI', severity: 'error', description: 'Local references and specification validity. Never baselined.' },
        { code: 'openapi-schema', kind: 'OpenAPI 3.1', severity: 'error', description: 'Embedded JSON Schema 2020-12 validity. Never baselined.' },
        { code: 'catalog-structure / catalog-reference', kind: 'catalog', severity: 'error', description: 'POC API entity subset and local definition target. Not full Backstage validation.' },
        { code: 'catalog-required', kind: 'all specifications', severity: 'error', description: 'Each interface has a matching local API catalog entity. Never baselined.' },
        ...rules,
      ].filter(matches);
      element('content').innerHTML = `<div class="table-scroll"><table><thead><tr><th>Proposed rule</th><th>Applies to</th><th>Severity</th></tr></thead><tbody>${checks.map(rule => `<tr><td><strong class="rule-name">${escape(rule.code)}</strong><span class="rule-description">${escape(rule.description)}</span></td><td>${escape(rule.kind)}</td><td><span class="severity ${rule.severity === 'warn' ? 'warning' : 'error'}">${rule.severity === 'warn' ? 'warning' : 'error'}</span></td></tr>`).join('')}</tbody></table></div>`;
    }
  }

  function render() {
    element('scenario-count').textContent = String(payload.results.length).padStart(2, '0');
    element('scenarios').innerHTML = payload.results.map((result, index) => `<button type="button" data-scenario="${escape(result.id)}" aria-pressed="${result.id === selected.id}"><span class="scenario-index">${String(index + 1).padStart(2, '0')}</span><span class="scenario-name">${escape(result.title)}<span class="scenario-outcome ${statusClass(result.status)}"><i></i>${result.status}</span></span>${icons['arrow-right']}</button>`).join('');
    element('scenario-title').textContent = selected.title;
    element('scenario-summary').textContent = selected.summary;
    element('status').className = `status ${statusClass(selected.status)}`;
    element('status').innerHTML = `${icons[selected.status === 'PASS' ? 'check' : 'circle-alert']}<strong>${selected.status}</strong><span>Exit code ${selected.exitCode}</span>`;
    element('metrics').innerHTML = [
      ['Blocking issues', selected.counts.blocking, 'blocking'],
      ['Existing debt', selected.counts.existing, 'debt'],
      ['Warnings', selected.counts.warnings, 'warnings'],
      ['Resolved findings', selected.counts.resolved, 'resolved'],
    ].map(([label, count, type]) => `<div class="metric ${type}"><span>${label}</span><strong>${count}</strong></div>`).join('');
    element('change-count').textContent = selected.changedFiles.length;
    element('run-time').textContent = new Date(payload.generatedAt).toLocaleString();
    renderContent();
  }

  element('scenarios').addEventListener('click', event => {
    const button = event.target.closest('[data-scenario]');
    if (!button) return;
    selected = payload.results.find(result => result.id === button.dataset.scenario);
    location.hash = selected.id;
    query = '';
    filter = 'new';
    element('search').value = '';
    render();
  });
  window.addEventListener('hashchange', () => {
    const result = payload.results.find(item => item.id === location.hash.slice(1));
    if (result && result.id !== selected.id) { selected = result; render(); }
  });
  document.querySelector('.tabs').addEventListener('click', event => {
    const button = event.target.closest('[data-tab]');
    if (!button) return;
    tab = button.dataset.tab;
    renderContent();
  });
  document.querySelector('.tabs').addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    const buttons = [...document.querySelectorAll('[data-tab]')];
    const current = buttons.findIndex(button => button.dataset.tab === tab);
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (current + (event.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length;
    event.preventDefault();
    buttons[next].click();
    buttons[next].focus();
  });
  element('filters').addEventListener('click', event => {
    const button = event.target.closest('[data-filter]');
    if (button) { filter = button.dataset.filter; renderContent(); }
  });
  element('search').addEventListener('input', event => { query = event.target.value.toLowerCase(); renderContent(); });
  element('download').addEventListener('click', () => {
    const { sources, ...result } = selected;
    const url = URL.createObjectURL(new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' }));
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${selected.id}.json`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  render();
}