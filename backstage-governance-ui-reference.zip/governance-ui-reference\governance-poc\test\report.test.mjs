import assert from 'node:assert/strict';
import { test } from 'node:test';
import vm from 'node:vm';
import { renderReport } from '../src/report.mjs';

test('report embeds local icons and safely serializes synthetic source text', async () => {
  const html = await renderReport({ generatedAt: '2026-10-29T12:00:00Z', results: [{ summary: '</script><img src=x onerror=alert(1)>' }] });
  assert.ok(html.includes('Interface Governance'));
  assert.ok(html.includes('No Azure PR connected'));
  assert.ok(html.includes('\\u003c/script>'));
  assert.ok(!html.includes('<img src=x'));
  assert.ok(!html.includes('<script src='));
  const script = html.match(/<script>([\s\S]*)<\/script>/)[1];
  assert.doesNotThrow(() => new vm.Script(script));
});