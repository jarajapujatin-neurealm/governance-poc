import path from 'node:path';
import { mkdir, writeFile } from 'node:fs/promises';
import { compareSnapshots } from './engine.mjs';
import { ensureSamples, projectRoot, readSnapshot } from './files.mjs';
import { scenarios } from './scenarios.mjs';
import { renderReport } from './report.mjs';

async function main() {
  await ensureSamples();
  const base = await readSnapshot(path.join(projectRoot, 'samples/target'));
  const results = [];
  const directory = path.join(projectRoot, 'reports');
  await mkdir(directory, { recursive: true });
  for (const scenario of scenarios) {
    const head = await readSnapshot(path.join(projectRoot, 'samples/scenarios', scenario.id));
    let result;
    try { result = await compareSnapshots(base, head); }
    catch (error) {
      result = { status: 'INCOMPLETE', exitCode: 2, error: error.message, changedFiles: [], findings: [], inventory: [], counts: { blocking: 0, existing: 0, warnings: 0, resolved: 0 } };
    }
    const { mutate, ...metadata } = scenario;
    results.push({ ...metadata, ...result, sources: Object.fromEntries([...new Set([...base.keys(), ...head.keys()])].filter(file => base.get(file) !== head.get(file)).map(file => [file, { before: base.get(file) ?? '', after: head.get(file) ?? '' }])) });
    await writeFile(path.join(directory, `${scenario.id}.json`), JSON.stringify(result, null, 2));
    console.log(`${result.status.padEnd(10)} ${scenario.id.padEnd(25)} expected ${scenario.expected} | ${result.counts.blocking} blocking, ${result.counts.existing} existing`);
  }
  const payload = { generatedAt: new Date().toISOString(), results };
  await writeFile(path.join(directory, 'results.json'), JSON.stringify(payload, null, 2));
  await writeFile(path.join(directory, 'index.html'), await renderReport(payload));
  const matched = results.filter(result => result.status === result.expected).length;
  console.log(`\n${matched}/${results.length} expected outcomes matched. Report: ${path.join(directory, 'index.html')}`);
  process.exitCode = matched === results.length ? 0 : 1;
}

main().catch(error => {
  console.error(`INCOMPLETE: ${error.message}`);
  process.exitCode = 2;
});