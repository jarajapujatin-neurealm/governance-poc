import assert from 'node:assert/strict';
import { test } from 'node:test';
import { parse } from 'yaml';
import { buildBackstagePublication } from '../src/backstage-publication.mjs';
import { baseSnapshot, scenarioSnapshot } from '../src/scenarios.mjs';

test('Backstage publication bundles definitions and connects provider/consumer entities', async () => {
  const head = scenarioSnapshot('compliant-api');
  const events = scenarioSnapshot('compliant-event');
  head.set('asyncapi/advance-events.yaml', events.get('asyncapi/advance-events.yaml'));
  head.set('catalog/advance-events.yaml', events.get('catalog/advance-events.yaml'));
  const publication = await buildBackstagePublication(baseSnapshot(), head);
  assert.equal(publication.result.status, 'PASS');
  assert.equal(publication.result.counts.existing, 10);
  const apis = publication.entities.filter(item => item.kind === 'API');
  assert.equal(apis.length, 12);
  for (const apiEntity of apis) {
    assert.equal(apiEntity.metadata.annotations['backstage.io/spectral-ruleset-url'], `http://localhost:3001/spectral-rules/${publication.result.rulesetVersion}/${apiEntity.spec.type}.json`);
  }
  assert.equal(parse(apis.find(item => item.metadata.name === 'member-api').spec.definition).openapi, '3.1.0');
  assert.ok(!apis.find(item => item.metadata.name === 'member-api').spec.definition.includes('../schemas/'));
  assert.equal(parse(apis.find(item => item.metadata.name === 'advance-events').spec.definition).asyncapi, '3.0.0');
  assert.equal(publication.entities.find(item => item.metadata.name === 'member-portal').spec.consumesApis.length, 2);
});

test('a failed governance snapshot cannot be published', async () => {
  await assert.rejects(buildBackstagePublication(baseSnapshot(), scenarioSnapshot('missing-owner')), /Publication blocked: FAIL/);
});