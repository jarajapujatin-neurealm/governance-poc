import { readFile } from 'node:fs/promises';
import { ruleCatalogue, RULESET_VERSION } from './rules.mjs';
import { mountReport } from './report-client.mjs';

const encode = value => JSON.stringify(value).replaceAll('<', '\\u003c').replaceAll('&', '\\u0026');

export async function renderReport(payload) {
  const iconNames = ['shield-check', 'git-pull-request', 'check', 'circle-alert', 'search', 'download', 'file-code', 'arrow-right', 'network', 'git-compare-arrows'];
  const icons = Object.fromEntries(await Promise.all(iconNames.map(async name => [name, await readFile(new URL(`../node_modules/lucide-static/icons/${name}.svg`, import.meta.url), 'utf8')])));
  const styles = await readFile(new URL('./report.css', import.meta.url), 'utf8');
  const packageJson = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Interface Governance | Local Research</title><style>${styles}</style></head>
<body>
  <header class="app-header">
    <div class="brand"><span class="brand-mark">${icons['shield-check']}</span><div><span class="eyebrow">ENGINEERING / LOCAL RESEARCH</span><h1>Interface Governance</h1></div></div>
    <div class="header-tags"><span class="tag">Synthetic data</span><span class="tag proposed">Proposed rules</span></div>
  </header>
  <div class="workspace">
    <aside class="scenario-panel" aria-label="Demonstration scenarios">
      <div class="section-label">VALIDATION SCENARIOS <span id="scenario-count"></span></div>
      <nav id="scenarios" aria-label="Choose a scenario"></nav>
      <div class="baseline-note"><span class="eyebrow">TARGET SNAPSHOT</span><strong>10 legacy findings</strong><span>10 APIs / 10 catalog entities</span><span class="mono">${RULESET_VERSION}</span></div>
    </aside>
    <main>
      <div class="run-meta"><span>${icons['git-pull-request']} Pull request rehearsal</span><span id="run-time"></span></div>
      <section class="result-heading" aria-labelledby="scenario-title"><div><span class="eyebrow">GOVERNANCE RESULT</span><h2 id="scenario-title"></h2><p id="scenario-summary"></p></div><div id="status" role="status" aria-live="polite"></div></section>
      <div class="metrics" id="metrics"></div>
      <div class="workflow" aria-label="Validation workflow"><span>${icons['file-code']} Target + proposed files</span>${icons['arrow-right']}<span>${icons['shield-check']} Real validators</span>${icons['arrow-right']}<span>${icons['git-compare-arrows']} Finding comparison</span></div>
      <div class="view-bar"><div class="tabs" role="tablist" aria-label="Report views"><button type="button" role="tab" data-tab="findings">Findings</button><button type="button" role="tab" data-tab="changes">Changes <span id="change-count"></span></button><button type="button" role="tab" data-tab="catalog">Catalog inventory</button><button type="button" role="tab" data-tab="rules">Proposed rules</button></div><button type="button" id="download" class="icon-button" title="Download scenario JSON" aria-label="Download scenario JSON">${icons.download}</button></div>
      <div class="table-tools"><div id="filters" class="segments" aria-label="Finding state"></div><label class="search">${icons.search}<input id="search" type="search" aria-label="Search report" placeholder="Search findings, files, owners..."></label></div>
      <section id="content" aria-label="Selected report view" role="tabpanel"></section>
      <footer><span>Local run / No Azure PR connected</span><span>Spectral ${packageJson.dependencies['@stoplight/spectral-core']} · OpenAPI parser ${packageJson.dependencies['@apidevtools/swagger-parser']} · AsyncAPI parser ${packageJson.dependencies['@asyncapi/parser']}</span></footer>
    </main>
  </div>
  <script type="application/json" id="report-data">${encode(payload)}</script>
  <script>(${mountReport.toString()})(JSON.parse(document.getElementById('report-data').textContent), ${encode(icons)}, ${encode(ruleCatalogue)});</script>
</body></html>`;
}