import path from 'node:path';
import { mkdir, writeFile } from 'node:fs/promises';
import { compareSnapshots } from './engine.mjs';
import { ensureSamples, projectRoot, readSnapshot } from './files.mjs';

async function main() {
  const argumentsList = process.argv.slice(2);
  const option = name => {
    const index = argumentsList.indexOf(name);
    if (index === -1) return undefined;
    const value = argumentsList[index + 1];
    if (!value || value.startsWith('--')) throw new Error(`Missing value for ${name}`);
    return value;
  };
  const allowed = new Set(['--scenario', '--base', '--head', '--out']);
  for (let index = 0; index < argumentsList.length; index += 2) {
    if (!allowed.has(argumentsList[index])) throw new Error(`Unknown option: ${argumentsList[index]}`);
    option(argumentsList[index]);
  }
  const scenario = option('--scenario');
  const baseOption = option('--base');
  const headOption = option('--head');
  if (scenario && (baseOption || headOption)) throw new Error('Use --scenario OR --base with --head.');
  if (!scenario && (!baseOption || !headOption)) throw new Error('Use --scenario <id> OR --base <directory> --head <directory>.');
  if (scenario && !/^[a-z0-9-]+$/.test(scenario)) throw new Error('Invalid scenario identifier.');
  if (scenario) await ensureSamples();
  const baseDirectory = scenario ? path.join(projectRoot, 'samples/target') : path.resolve(baseOption);
  const headDirectory = scenario ? path.join(projectRoot, 'samples/scenarios', scenario) : path.resolve(headOption);
  const result = await compareSnapshots(await readSnapshot(baseDirectory), await readSnapshot(headDirectory));
  const output = option('--out') ? path.resolve(option('--out')) : path.join(projectRoot, 'reports/check.json');
  await mkdir(path.dirname(output), { recursive: true });
  await writeFile(output, JSON.stringify(result, null, 2));
  console.log(`${result.status} | blockers: ${result.counts.blocking} | existing debt: ${result.counts.existing} | resolved: ${result.counts.resolved} | warnings: ${result.counts.warnings}`);
  for (const item of result.findings.filter(item => item.state === 'new')) {
    console.log(`  ${item.severity.toUpperCase()} ${item.file} ${item.location} [${item.code}] ${item.message}`);
  }
  if (result.baselineInvalid) console.error('Target snapshot is structurally invalid. Governance comparison is incomplete.');
  console.log(`JSON report: ${output}`);
  process.exitCode = result.exitCode;
}

main().catch(error => {
  console.error(`INCOMPLETE: ${error.message}`);
  process.exitCode = 2;
});