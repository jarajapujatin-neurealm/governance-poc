# Local Interface Governance POC

Runnable R&D for the October 29 meeting. All interface data is synthetic and all organizational rules are proposed, not bank-approved. No cloud credentials, bank repository, Azure connection, or Backstage server is required.

## Run

Use the installed Node.js 24 runtime and npm. From this directory:

```powershell
npm ci
npm test
npm run demo
```

Open [the report](reports/index.html) in a browser. It is a standalone HTML file with embedded data, styles, JavaScript, and Lucide icons. It has no server, CDN, runtime network requests, or font downloads. Scenario selection displays results already computed by the real validators; it does not rerun Node.js in the browser.

`npm run demo` initially creates the sample snapshots, runs all ten scenarios, and writes the HTML and JSON reports. Later runs use the existing samples, so local edits are preserved. Regenerate the report after editing specifications. The command succeeds when all actual outcomes match the expected demonstration outcomes; individual scenarios intentionally fail.

## Present The Demo

1. Select **Compliant new API**. Ten legacy APIs have valid specifications but lack operation identifiers. The new eleventh API passes; the ten old findings remain visible under **Existing**.
2. Select **Missing owner**. Show the new blocking `catalog-owner` finding. Use **Changes** to inspect the proposed entity beside the target snapshot.
3. Select **Compliant new event**, then **Invalid event structure**. The official AsyncAPI parser accepts the valid 3.0 document and rejects an invalid operation action.
4. Select **New debt in a legacy API**. A new operation in an existing file is rejected without reclassifying the old violation as new debt.
5. Select **Legacy issue resolved**. Known debt drops from ten to nine, and the fixed finding appears under **Resolved**.
6. Select **Shared schema regression**. Only the shared schema file changes, but ten dependent APIs are revalidated and fail.
7. Open **Catalog inventory** and **Proposed rules**. These show local entity metadata and the exact checks, not a running Backstage portal.

Additional cases cover malformed YAML, unsupported specification versions, and nonblocking documentation warnings. Findings have file paths and JSON Pointer locations; structural validators may report the document root and more detailed locations in their messages.

## Run A Real Gate Locally

```powershell
npm run check -- --scenario compliant-api
npm run check -- --scenario missing-owner
npm run check -- --scenario legacy-fixed
```

Exit codes:

| Code | Meaning |
| --- | --- |
| `0` | PASS: no new blocking debt |
| `1` | FAIL: blocking findings |
| `2` | INCOMPLETE: tool/input failure or structurally invalid target snapshot |

The second command is expected to return `1`. Report JSON is written to `reports/check.json` for completed comparisons. Tool or input failures print `INCOMPLETE` and do not produce a new success report; automation must always honor the exit code rather than read an old artifact.

To compare your own local snapshots:

```powershell
npm run check -- --base ./samples/target --head ./samples/scenarios/missing-owner --out ./reports/my-check.json
```

Each snapshot uses `openapi/`, `asyncapi/`, `catalog/`, and optional shared `schemas/` directories. Specifications are identified by their directory, not arbitrary filenames. Each API/event specification needs a separate Backstage `kind: API` entity referencing its local file through `spec.definition.$text`. Catalog files contain one entity each. Owner and system references are required but their target Group/System entities are not resolved by this POC.

## What Runs For Real

| Responsibility | Implementation |
| --- | --- |
| Governance linting | Spectral core and functions; actual findings, not canned results |
| OpenAPI validity | APIDevTools Swagger Parser; OpenAPI 3.0.x and 3.1.x |
| OpenAPI 3.1 schema validity | Additional Ajv 2020-12 meta-schema validation; necessary because document structure validation alone misses some invalid embedded schemas |
| AsyncAPI validity | Official AsyncAPI Parser; explicitly limited to 3.0.0 for this POC |
| Local references | JSON Schema Ref Parser, using an in-memory snapshot resolver; no HTTP resolution or outside-snapshot file reads |
| Catalog validation | Ajv validation of a deliberately limited API entity profile, local definition checks, local entity identity collisions, and catalog coverage |
| Legacy policy | Compare individual lint findings against the target snapshot using the same ruleset |
| Reporting | Offline HTML plus machine-readable JSON |

Proposed lint rules: HTTP `operationId`, event operation `summary`, catalog `owner` and `system` are errors. API/event business descriptions are warnings. These are demonstration standards, not an exhaustive design/security policy.

The target snapshot is the baseline, not a count supplied by a developer. Finding identity includes file, rule code, JSON Pointer, and message. A violation fixed in one location cannot offset a new violation elsewhere. All specifications in both snapshots are scanned, including dependents of shared schemas. Only existing lint debt is baselineable; syntax, reference, version, specification, catalog-structure, and embedded-schema failures are not. A structurally invalid target makes comparison incomplete rather than trusted.

## Optional Local Backstage Portal

A real companion Backstage application is now available in [the portal project](../backstage-portal/LOCAL-DEMO.md). It displays the synthetic APIs/events using native API Docs, ownership and producer/consumer relationships, and catalog graphs. Its Governance page embeds this generated report.

After a successful `npm run demo`, publish a combined passing API/event snapshot with:

```powershell
node src/publish-backstage.mjs
```

The exporter reruns governance and refuses failing snapshots. It preserves the ten accepted legacy lint findings and bundles specification references for Backstage ingestion. The publication builder has regression tests for passing and rejected snapshots. This is a manual local handoff, not automatic CI/CD. See the portal walkthrough for WSL startup, URLs, and refresh steps.

## Limits Before Production

- This is a local snapshot comparison, not a Git/PR service. Trusted target extraction, merge-base handling, protected rules/templates, baseline approval, expiring exceptions, and build-validation branch policies require real repository integration.
- This report's **Catalog inventory** remains a local metadata table, not a Backstage UI. The companion portal now provides real entity processing and Group/System/Domain relationships with local guest sign-in; production identity, repository discovery, and automatic publication are not implemented.
- Deleted or renamed interfaces are not analyzed for compatibility. Finding identity follows paths and can change on renames; no breaking-change policy is enforced.
- No cross-repository duplicate/semantic detection or compatibility analysis is implemented. Shared paths/topics are not automatically considered duplicates.
- OpenAPI checks are not a complete semantic/security audit. The 3.1 check uses JSON Schema 2020-12, not every custom OpenAPI dialect or external schema language. AsyncAPI 2.x and other payload schema formats are outside the demonstrated support matrix.
- Inputs are synthetic and local; this is not a hardened service for hostile uploads. Remote references, symbolic-link snapshot files, and outside-snapshot reference reads are rejected.
- The baseline directories are editable for this demonstration, not access-controlled. Ruleset changes must be reviewed separately in a production rollout.

## Azure Integration Boundary

A future Azure Pipeline should prepare trusted target and proposed snapshots, install pinned dependencies with `npm ci`, run the `check` command, and publish its result even on failure. Preserve the command's nonzero exit code. Configure a **required build-validation branch policy** on the Azure Repos target branch; a YAML `pr:` trigger is not the Azure Repos Git enforcement mechanism. Do not use `npm run demo` as the real PR gate: it tests expected scenarios, including expected failures.

## Files

- `src/rules.mjs`: versioned proposed Spectral rules.
- `src/engine.mjs`: validators, reference restrictions, and per-finding comparison.
- `src/scenarios.mjs`: reproducible synthetic scenario definitions.
- `samples/target/`: ten legacy APIs and their catalog entities.
- `samples/scenarios/`: complete proposed snapshots; inspect or edit these for local experiments.
- `reports/index.html`: generated interactive report.
- `reports/results.json`: aggregate run results, with per-scenario JSON alongside it.
- `test/`: executable Node.js regression tests.

## Upstream References

- [Spectral](https://github.com/stoplightio/spectral)
- [Swagger Parser](https://apidevtools.com/swagger-parser/)
- [AsyncAPI Parser](https://github.com/asyncapi/parser-js)
- [Backstage API entity model](https://backstage.io/docs/features/software-catalog/descriptor-format/#kind-api)
- [Azure Repos build validation](https://learn.microsoft.com/en-us/azure/devops/repos/git/branch-policies?view=azure-devops&tabs=browser#build-validation)