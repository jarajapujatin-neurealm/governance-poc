import assert from 'node:assert/strict';
import { test } from 'node:test';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { readSnapshot } from '../src/files.mjs';

test('snapshot loading preserves portable file paths and rejects empty inputs', async () => {
  const directory = await mkdtemp(path.join(os.tmpdir(), 'governance-test-'));
  try {
    await assert.rejects(readSnapshot(directory), /No specifications/);
    await mkdir(path.join(directory, 'openapi'));
    await writeFile(path.join(directory, 'openapi', 'example.yaml'), 'openapi: 3.1.0');
    const snapshot = await readSnapshot(directory);
    assert.equal(snapshot.get('openapi/example.yaml'), 'openapi: 3.1.0');
  } finally { await rm(directory, { recursive: true }); }
});