import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readdir, readFile, mkdir, writeFile, access } from 'node:fs/promises';
import { baseSnapshot, scenarioSnapshot, scenarios } from './scenarios.mjs';

export const projectRoot = fileURLToPath(new URL('../', import.meta.url));

export async function readSnapshot(directory) {
  const snapshot = new Map();
  async function visit(relative = '') {
    for (const entry of await readdir(path.join(directory, relative), { withFileTypes: true })) {
      const name = relative ? `${relative}/${entry.name}` : entry.name;
      if (entry.isSymbolicLink()) throw new Error(`Symbolic links are not allowed in snapshots: ${name}`);
      if (entry.isDirectory()) await visit(name);
      else if (/\.(ya?ml|json)$/i.test(name)) snapshot.set(name, await readFile(path.join(directory, name), 'utf8'));
    }
  }
  await visit();
  if (![...snapshot.keys()].some(file => /^(openapi|asyncapi|catalog)\//.test(file))) {
    throw new Error('No specifications found. Use openapi/, asyncapi/, and catalog/ directories.');
  }
  return snapshot;
}

export async function ensureSamples() {
  const directory = path.join(projectRoot, 'samples');
  try { await access(directory); return; }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  async function saveSnapshot(name, snapshot) {
    for (const [file, text] of snapshot) {
      const destination = path.join(directory, name, file);
      await mkdir(path.dirname(destination), { recursive: true });
      await writeFile(destination, text, { flag: 'wx' });
    }
  }
  await saveSnapshot('target', baseSnapshot());
  for (const scenario of scenarios) await saveSnapshot(`scenarios/${scenario.id}`, scenarioSnapshot(scenario.id));
}