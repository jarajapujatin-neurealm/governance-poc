import path from 'node:path';
import { mkdir, writeFile, copyFile } from 'node:fs/promises';
import { stringify } from 'yaml';
import { ensureSamples, projectRoot, readSnapshot } from './files.mjs';
import { buildBackstagePublication } from './backstage-publication.mjs';
import { portableRuleset, RULESET_VERSION } from './rules.mjs';

async function main() {
  await ensureSamples();
  const base = await readSnapshot(path.join(projectRoot, 'samples/target'));
  const head = await readSnapshot(path.join(projectRoot, 'samples/scenarios/compliant-api'));
  const events = await readSnapshot(path.join(projectRoot, 'samples/scenarios/compliant-event'));
  for (const [file, text] of events) {
    if (file.startsWith('asyncapi/') || file === 'catalog/advance-events.yaml') head.set(file, text);
  }
  const publication = await buildBackstagePublication(base, head);
  const portal = path.resolve(projectRoot, '../backstage-portal');
  const demo = path.join(portal, 'demo');
  const publicReports = path.join(portal, 'packages/app/public/governance-report');
  const publicRules = path.join(portal, 'packages/app/public/spectral-rules', RULESET_VERSION);
  await mkdir(demo, { recursive: true });
  await mkdir(publicReports, { recursive: true });
  await mkdir(publicRules, { recursive: true });
  for (const kind of ['openapi', 'asyncapi']) {
    await writeFile(path.join(publicRules, `${kind}.json`), JSON.stringify(portableRuleset(kind), null, 2));
  }
  await copyFile(path.join(projectRoot, 'reports/index.html'), path.join(publicReports, 'index.html'));
  await copyFile(path.join(projectRoot, 'reports/results.json'), path.join(publicReports, 'results.json'));
  await writeFile(path.join(demo, 'entities.yaml'), publication.entities.map(item => stringify(item)).join('---\n'));
  await writeFile(path.join(demo, 'publication.json'), JSON.stringify({ generatedAt: new Date().toISOString(), ...publication.result }, null, 2));
  console.log(`Published ${publication.entities.length} synthetic Backstage entities after PASS; ${publication.result.counts.existing} existing findings retained.`);
}

main().catch(error => { console.error(error.message); process.exitCode = 1; });