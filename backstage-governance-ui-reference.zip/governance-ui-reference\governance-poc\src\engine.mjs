import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { parseDocument } from 'yaml';
import Ajv from 'ajv';
import Ajv2020 from 'ajv/dist/2020.js';
import RefParser from '@apidevtools/json-schema-ref-parser';
import SwaggerParser from '@apidevtools/swagger-parser';
import { Parser as AsyncParser } from '@asyncapi/parser';
import { lintDocument, RULESET_VERSION } from './rules.mjs';

const virtualRoot = path.resolve('governance-snapshot');
const asyncParser = new AsyncParser();
const ajv = new Ajv({ allErrors: true });
const schemaValidator = new Ajv2020({ allErrors: true, strict: false, validateFormats: false });
const nonempty = { type: 'string', minLength: 1, pattern: '\\S' };
const validateCatalog = ajv.compile({
  type: 'object',
  required: ['apiVersion', 'kind', 'metadata', 'spec'],
  properties: {
    apiVersion: { const: 'backstage.io/v1alpha1' },
    kind: { const: 'API' },
    metadata: {
      type: 'object', required: ['name'],
      properties: { name: { type: 'string', pattern: '^[a-z0-9]+(?:[._-][a-z0-9]+)*$', maxLength: 63 } },
    },
    spec: {
      type: 'object', required: ['type', 'lifecycle', 'definition'],
      properties: {
        type: { enum: ['openapi', 'asyncapi'] },
        lifecycle: nonempty,
        owner: nonempty,
        system: nonempty,
        definition: {
          type: 'object', required: ['$text'],
          additionalProperties: false, properties: { $text: nonempty },
        },
      },
    },
  },
});

function pointer(parts) {
  return '/' + parts.map(part => String(part).replaceAll('~', '~0').replaceAll('/', '~1')).join('/');
}

function finding(file, code, location, message, severity = 'error', baselineable = false) {
  const identity = JSON.stringify([file, code, location, message]);
  return {
    id: createHash('sha256').update(identity).digest('hex').slice(0, 20),
    file, code, location, message, severity, baselineable,
  };
}

function resolveLocal(file, reference) {
  if (/^[a-z][a-z0-9+.-]*:|^[/\\]|\\/i.test(reference)) {
    throw new Error('Only relative, snapshot-local references are allowed.');
  }
  const resolved = path.posix.normalize(path.posix.join(path.posix.dirname(file), reference));
  if (resolved === '..' || resolved.startsWith('../')) throw new Error('Reference leaves the snapshot.');
  return resolved;
}

export async function bundle(snapshot, file, document) {
  return RefParser.bundle(path.join(virtualRoot, file), structuredClone(document), {
    resolve: {
      http: false,
      file: {
        canRead: true,
        read(resource) {
          const resourcePath = resource.url.startsWith('file:') ? fileURLToPath(resource.url) : decodeURIComponent(resource.url);
          const relative = path.relative(virtualRoot, resourcePath).split(path.sep).join('/');
          if (relative.startsWith('../') || path.isAbsolute(relative) || !snapshot.has(relative)) {
            throw new Error('Reference is unavailable inside this snapshot.');
          }
          return snapshot.get(relative);
        },
      },
    },
  });
}

export async function validateSnapshot(snapshot) {
  const findings = [];
  const inventory = [];
  const registeredSpecifications = new Set();
  const entityIdentities = new Set();
  let evaluated = 0;
  for (const [file, text] of [...snapshot].sort(([first], [second]) => first.localeCompare(second))) {
    if (!/\.(ya?ml|json)$/i.test(file)) continue;
    const yaml = parseDocument(text, { uniqueKeys: true });
    if (yaml.errors.length) {
      findings.push(finding(file, 'syntax', '/', yaml.errors[0].message));
      continue;
    }
    let document;
    try { document = yaml.toJS({ maxAliasCount: 50 }); }
    catch (error) { findings.push(finding(file, 'syntax', '/', error.message)); continue; }
    const kind = file.startsWith('openapi/') ? 'openapi'
      : file.startsWith('asyncapi/') ? 'asyncapi'
        : file.startsWith('catalog/') ? 'catalog' : undefined;
    if (!kind) continue;
    evaluated += 1;
    if (!document || typeof document !== 'object' || Array.isArray(document)) {
      findings.push(finding(file, 'spec-structure', '/', 'Expected a specification object.'));
      continue;
    }
    const version = kind === 'openapi' ? document.openapi : document.asyncapi;
    if (kind !== 'catalog' && !(kind === 'openapi' ? /^3\.[01]\.\d+$/ : /^3\.0\.0$/).test(version ?? '')) {
      findings.push(finding(file, 'supported-version', '/', 'Supported: OpenAPI 3.0.x / 3.1.x or AsyncAPI 3.0.0.'));
      continue;
    }
    let resolved = document;
    if (kind === 'catalog') {
      if (!validateCatalog(document)) {
        for (const error of validateCatalog.errors) {
          findings.push(finding(file, 'catalog-structure', error.instancePath || '/', error.message));
        }
        continue;
      }
      try {
        const identity = `${document.metadata.namespace ?? 'default'}/${document.metadata.name}`.toLowerCase();
        if (entityIdentities.has(identity)) throw new Error('Duplicate API entity name and namespace in this snapshot.');
        entityIdentities.add(identity);
        const definitionFile = resolveLocal(file, document.spec.definition.$text);
        if (!snapshot.has(definitionFile)) throw new Error('Catalog definition file does not exist.');
        const definition = parseDocument(snapshot.get(definitionFile)).toJS();
        if (!definition?.[document.spec.type]) throw new Error('Catalog type does not match the referenced specification.');
        registeredSpecifications.add(definitionFile);
      } catch (error) {
        findings.push(finding(file, 'catalog-reference', '/spec/definition', error.message));
      }
      inventory.push({ file, name: document.metadata.name, ...document.spec, definition: document.spec.definition.$text });
    } else {
      try { resolved = await bundle(snapshot, file, document); }
      catch (error) {
        findings.push(finding(file, 'spec-reference', '/', error.message));
        continue;
      }
      if (kind === 'openapi') {
        try { await SwaggerParser.validate(structuredClone(resolved), { resolve: { external: false } }); }
        catch (error) {
          if (!(error instanceof SyntaxError) && !error.details) throw error;
          findings.push(finding(file, 'openapi-structure', '/', error.message));
          continue;
        }
        if (document.openapi.startsWith('3.1.')) {
          const inspect = (node, location = []) => {
            if (!node || typeof node !== 'object') return;
            for (const [key, value] of Object.entries(node)) {
              if (['example', 'examples', 'default', 'enum', 'const'].includes(key)) continue;
              const isSchema = key === 'schema' || (location.at(-1) === 'schemas' && location.at(-2) === 'components');
              if (isSchema && !schemaValidator.validateSchema(value)) {
                findings.push(finding(file, 'openapi-schema', pointer([...location, key]), schemaValidator.errorsText()));
              }
              inspect(value, [...location, key]);
            }
          };
          inspect(resolved);
        }
      } else {
        const result = await asyncParser.parse(structuredClone(resolved));
        const errors = result.diagnostics.filter(diagnostic => diagnostic.severity === 0);
        if (errors.length || !result.document) {
          for (const error of errors) findings.push(finding(file, 'asyncapi-structure', pointer(error.path ?? []), error.message));
          if (!errors.length) findings.push(finding(file, 'asyncapi-structure', '/', 'AsyncAPI parser returned no valid document.'));
          continue;
        }
      }
    }
    for (const result of await lintDocument(resolved, kind)) {
      findings.push(finding(file, String(result.code), pointer(result.path), result.message, result.severity === 0 ? 'error' : 'warning', true));
    }
  }
  for (const file of snapshot.keys()) {
    if (/^(openapi|asyncapi)\/.*\.(ya?ml|json)$/i.test(file) && !registeredSpecifications.has(file)) {
      findings.push(finding(file, 'catalog-required', '/', 'Each specification must have a matching local API catalog entity.'));
    }
  }
  return { findings, inventory, evaluated };
}

export async function compareSnapshots(base, head) {
  const baseResult = await validateSnapshot(base);
  const headResult = await validateSnapshot(head);
  const known = new Set(baseResult.findings.filter(item => item.baselineable).map(item => item.id));
  const current = new Set(headResult.findings.map(item => item.id));
  const findings = headResult.findings.map(item => ({ ...item, state: known.has(item.id) ? 'existing' : 'new' }));
  const resolved = baseResult.findings.filter(item => item.baselineable && !current.has(item.id)).map(item => ({ ...item, state: 'resolved' }));
  const blockers = findings.filter(item => item.severity === 'error' && (item.state === 'new' || !item.baselineable));
  const baselineInvalid = baseResult.findings.some(item => !item.baselineable && item.severity === 'error');
  const changedFiles = [...new Set([...base.keys(), ...head.keys()])].filter(file => base.get(file) !== head.get(file)).sort();
  return {
    rulesetVersion: RULESET_VERSION,
    status: baselineInvalid ? 'INCOMPLETE' : blockers.length ? 'FAIL' : 'PASS',
    exitCode: baselineInvalid ? 2 : blockers.length ? 1 : 0,
    baselineInvalid, changedFiles, findings: [...findings, ...resolved],
    inventory: headResult.inventory, evaluated: headResult.evaluated,
    counts: {
      blocking: blockers.length,
      existing: findings.filter(item => item.state === 'existing' && item.severity === 'error').length,
      warnings: findings.filter(item => item.severity === 'warning').length,
      resolved: resolved.length,
    },
  };
}