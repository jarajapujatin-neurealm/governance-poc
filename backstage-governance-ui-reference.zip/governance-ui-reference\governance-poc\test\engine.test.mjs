import assert from 'node:assert/strict';
import { test } from 'node:test';
import { stringify } from 'yaml';
import { compareSnapshots, validateSnapshot } from '../src/engine.mjs';
import { api, catalog, baseSnapshot, scenarioSnapshot, scenarios } from '../src/scenarios.mjs';

for (const scenario of scenarios) {
  test(`scenario ${scenario.id}: ${scenario.expected}`, async () => {
    const result = await compareSnapshots(baseSnapshot(), scenarioSnapshot(scenario.id));
    assert.equal(result.status, scenario.expected, JSON.stringify(result.findings.filter(item => item.state === 'new'), null, 2));
    assert.equal(result.exitCode, scenario.expected === 'PASS' ? 0 : 1);
    if (scenario.id === 'compliant-api') {
      assert.equal(result.counts.existing, 10);
      assert.equal(result.counts.blocking, 0);
      assert.equal(result.inventory.length, 11);
    }
    if (scenario.id === 'legacy-fixed') {
      assert.equal(result.counts.existing, 9);
      assert.equal(result.counts.resolved, 1);
    }
    if (scenario.id === 'shared-schema-broken') {
      assert.deepEqual(result.changedFiles, ['schemas/advance.yaml']);
      assert.ok(result.findings.some(item => item.file === 'openapi/legacy-api-01.yaml' && item.state === 'new'));
    }
  });
}

test('equal finding counts cannot hide a different new violation', async () => {
  const head = baseSnapshot();
  const document = api('Legacy API 1', 'fixedOperation');
  document.paths['/new-path'] = { get: { responses: { 200: { description: 'Success' } } } };
  head.set('openapi/legacy-api-01.yaml', stringify(document));
  const result = await compareSnapshots(baseSnapshot(), head);
  assert.equal(result.status, 'FAIL');
  assert.equal(result.counts.blocking, 1);
  assert.equal(result.counts.resolved, 1);
});

test('malformed baseline cannot be silently grandfathered', async () => {
  const base = baseSnapshot();
  base.set('openapi/legacy-api-01.yaml', 'openapi: [');
  const result = await compareSnapshots(base, baseSnapshot());
  assert.equal(result.status, 'INCOMPLETE');
  assert.equal(result.exitCode, 2);
});

test('remote and outside-snapshot references are rejected', async () => {
  for (const reference of ['https://example.invalid/schema.yaml', '../../secret.yaml']) {
    const document = api('Unsafe reference');
    document.paths['/advances'].get.responses[200].content['application/json'].schema.$ref = reference;
    const result = await validateSnapshot(new Map([['openapi/api.yaml', stringify(document)]]));
    assert.ok(result.findings.some(item => item.code === 'spec-reference'));
  }
});

test('OpenAPI 3.0.3 and AsyncAPI operation governance are validated', async () => {
  const head = scenarioSnapshot('compliant-event');
  const document = api('OpenAPI 3.0');
  document.openapi = '3.0.3';
  head.set('openapi/advance-api.yaml', stringify(document));
  head.set('catalog/advance-api.yaml', stringify(catalog('advance-api')));
  const result = await compareSnapshots(baseSnapshot(), head);
  assert.equal(result.status, 'PASS');
  const eventText = head.get('asyncapi/advance-events.yaml');
  head.set('asyncapi/advance-events.yaml', eventText.replace('summary: Publish an advance verification', 'description: Publish an advance verification'));
  const invalid = await compareSnapshots(baseSnapshot(), head);
  assert.ok(invalid.findings.some(item => item.code === 'event-operation-summary' && item.state === 'new'));
});

test('a valid new API without a catalog entity is blocking', async () => {
  const head = scenarioSnapshot('compliant-api');
  head.delete('catalog/member-api.yaml');
  const result = await compareSnapshots(baseSnapshot(), head);
  assert.equal(result.status, 'FAIL');
  assert.ok(result.findings.some(item => item.code === 'catalog-required' && item.file === 'openapi/member-api.yaml'));
});