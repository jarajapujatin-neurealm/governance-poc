import assert from 'node:assert/strict';
import { test } from 'node:test';
import { Spectral } from '@stoplight/spectral-core';
import { truthy } from '@stoplight/spectral-functions';
import { lintDocument, portableRuleset, ruleCatalogue } from '../src/rules.mjs';
import { api, event } from '../src/scenarios.mjs';

test('portable browser rules retain the CLI catalogue and findings', async () => {
  for (const kind of ['openapi', 'asyncapi']) {
    const portable = JSON.parse(JSON.stringify(portableRuleset(kind)));
    assert.deepEqual(Object.keys(portable.rules), ruleCatalogue.filter(rule => rule.kind === kind).map(rule => rule.code));
    const document = kind === 'openapi' ? api('Legacy API', null) : event();
    if (kind === 'asyncapi') delete document.operations.publishAdvanceVerified.summary;
    for (const rule of Object.values(portable.rules)) {
      assert.equal(rule.then.function, 'truthy');
      rule.then.function = truthy;
    }
    const spectral = new Spectral();
    spectral.setRuleset(portable);
    const expected = await lintDocument(document, kind);
    const actual = await spectral.run(document, { resolve: false });
    assert.deepEqual(actual.map(item => [item.code, item.severity, item.path]), expected.map(item => [item.code, item.severity, item.path]));
    assert.ok(actual.some(item => item.severity === 0));
  }
});

test('ruleset exports are independent and reject unsupported kinds', () => {
  const first = portableRuleset('openapi');
  first.rules['api-operation-id'].severity = 'warn';
  assert.equal(portableRuleset('openapi').rules['api-operation-id'].severity, 'error');
  assert.throws(() => portableRuleset('unknown'), /Unknown ruleset/);
});