import { Spectral } from '@stoplight/spectral-core';
import { truthy } from '@stoplight/spectral-functions';

export const RULESET_VERSION = 'proposed-1.0.0';

export const ruleCatalogue = [
  { code: 'api-description', kind: 'openapi', given: '$.info', field: 'description', severity: 'warn', description: 'Describe the API business purpose.' },
  { code: 'api-operation-id', kind: 'openapi', given: "$.paths[*]['get','post','put','patch','delete','options','head','trace']", field: 'operationId', severity: 'error', description: 'Each HTTP operation must have an operationId.' },
  { code: 'event-description', kind: 'asyncapi', given: '$.info', field: 'description', severity: 'warn', description: 'Describe the event interface business purpose.' },
  { code: 'event-operation-summary', kind: 'asyncapi', given: '$.operations[*]', field: 'summary', severity: 'error', description: 'Each event operation must have a summary.' },
  { code: 'catalog-owner', kind: 'catalog', given: '$.spec', field: 'owner', severity: 'error', description: 'Each API entity must declare an owner.' },
  { code: 'catalog-system', kind: 'catalog', given: '$.spec', field: 'system', severity: 'error', description: 'Each API entity must declare a system.' },
];

export function portableRuleset(kind) {
  if (!['openapi', 'asyncapi', 'catalog'].includes(kind)) throw new Error(`Unknown ruleset kind: ${kind}`);
  return {
    rules: Object.fromEntries(ruleCatalogue.filter(rule => rule.kind === kind).map(rule => [rule.code, {
      description: rule.description,
      message: rule.description,
      severity: rule.severity,
      given: rule.given,
      then: { field: rule.field, function: 'truthy' },
    }])),
  };
}

export async function lintDocument(document, kind) {
  const spectral = new Spectral();
  const ruleset = portableRuleset(kind);
  for (const rule of Object.values(ruleset.rules)) rule.then.function = truthy;
  spectral.setRuleset(ruleset);
  return spectral.run(document, { resolve: false });
}